import React, { Component } from 'react';
import logo from './logo.svg';
import './css/App.css';
import Login from './components/Login';




class App extends Component {
  render() {
    return (
	<div className="outer">
      <div className="App">
        <Login/>
		
      </div>
	  </div>
    );
  }
}

export default App;
